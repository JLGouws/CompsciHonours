% University of Surrey
%
% This file is part of TLD.
%
% webcam clear
delete(vid);
clear vid;
