% University of Surrey
%
% This file is part of TLD.
%


beep off;
clc; clf;
clear tld;
clear global;
warning off all;
rand('state',0);
randn('state',0);
close all;
addpath(genpath('.'));
tic;
