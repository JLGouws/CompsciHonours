% University of Surrey
%
% This file is part of TLD.
%

function s = bb_size(bb)

s = [bb(4,:)-bb(2,:)+1; bb(3,:)-bb(1,:)+1];

