% University of Surrey
%
% This file is part of TLD.
%


function bbH = bb_height(bb)
% Info

bbH    = bb(4,:)-bb(2,:)+1;


