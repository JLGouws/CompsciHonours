% University of Surrey
%
% This file is part of TLD.
%


function bbW = bb_width(bb)
% Info

bbW    = bb(3,:)-bb(1,:)+1;


