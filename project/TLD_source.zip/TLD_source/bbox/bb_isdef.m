% University of Surrey
%
% This file is part of TLD.
%


function id = bb_isdef(bb)
% Info

id = isfinite(bb(1,:));
